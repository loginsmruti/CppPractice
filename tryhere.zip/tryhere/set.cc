#include <iostream>
#include <set>

int main ()
{
   std::set<int> myset;
   std::set<int>::iterator it;
   std::pair<std::set<int>::iterator,bool> ret;

#if 1

   // set some initial values:
   for (int i=1; i<=5; ++i) myset.insert(i*10);    // set: 10 20 30 40 50

   ret = myset.insert(60);               // no new element inserted

   if (ret.second==true)
      it=ret.first;  // "it" now points to element 20

   myset.insert (it,25);                 // max efficiency inserting
   myset.insert (it,24);                 // max efficiency inserting
   myset.insert (it,26);                 // no max efficiency inserting

   int myints[]= {5,10,15};              // 10 already in set, not inserted
   myset.insert (myints,myints+3);

#endif

   std::cout << "myset contains:";
   for (it=myset.begin(); it!=myset.end(); ++it)
      std::cout << ' ' << *it;
   std::cout << '\n';

   return 0;
}
