#include <iostream>
#include <vector>
#include <algorithm>
#include <string>

using namespace std;


class Employee {
    string name;
    unsigned number;
public:
    Employee() { name = ""; number = 0; }
    
    Employee(string n, unsigned num) {
        name = n;
        number = num;
    }
    string get_name() { return name; }
    unsigned get_number() { return number; }
};

void show(vector<Employee> vect) {
    vector<Employee>::iterator itr;
    
    for(itr=vect.begin(); itr != vect.end(); ++itr)
        cout << itr->get_number() << " " << itr->get_name() << endl;;
    
}
int main()
{
    vector<Employee> employeeList;
    
    employeeList.push_back(Employee("A", 9));
    employeeList.push_back(Employee("B", 8));
    employeeList.push_back(Employee("C", 6));
    employeeList.push_back(Employee("D", 1));
    
    show(employeeList);
    
    return 0;
}
