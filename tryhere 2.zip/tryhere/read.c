#include <unistd.h>
#define MAXBUFF 10

int main()
{
  int fd;
  int ret;

  fd = open("example.txt" , O_RDONLY);
   
  
   exit(0);
}
