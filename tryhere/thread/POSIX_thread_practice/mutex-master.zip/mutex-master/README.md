# mutex

Example code from my Mutex Class in C++ blog. 

## Build

1. Get the [_threads_](https://github.com/vichargrave/threads.git) code.
2. Place the threads directory at the same directory level, e.g. `${HOME}/src/threads`, `${HOME}/src/mutex`.
3. cd to the `mutex` directory.
4. Run `make`.
5. Run the test application `mutex`.
