# threads

Example code from my Java Style Threads Class in C++ blog.

## Build

1. cd to the `threads` directory.
2. Type `make`'.
3. Run the test application `thread`.
