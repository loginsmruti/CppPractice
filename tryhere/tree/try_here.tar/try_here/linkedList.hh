#ifndef LINKED_LIST_H
#define LINKED_LIST_H
struct Node
{
   int data;
   Node *next = nullptr;
};

class LinkedList
{
   public:
      LinkedList();
      LinkedList(const LinkedList &list);
      ~LinkedList();
      LinkedList & operator=(const LinkedList &other);
      LinkedList & operator+=(const LinkedList &rhs);
      friend LinkedList operator+(const LinkedList &lhs, const LinkedList &rhs);

      bool IsEmpty() const;
      void Append(int value); // add to end
      void Insert(int value); // add to beginning
      void Print() const;

   protected:       
      // Protected so that derived class can modify these directly
      Node *head;
      Node *tail; // allows O(1) append

   private:
      void swap(LinkedList &other);

};

#endif
