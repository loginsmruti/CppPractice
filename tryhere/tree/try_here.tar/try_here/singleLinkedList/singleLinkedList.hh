#ifndef _SINGLE_LINKED_LIST_HH
#define _SINGLE_LINKED_LIST_HH

#include<iostream>

struct Node {
   int data;
   struct Node* next;
};

class LinkedList 
{
  public:
    LinkedList();
    LinkedList(const LinkedList& objList);
    ~LinkedList();

    void insert(int value);
    void append(int value);
    bool isEmpty() const;

    void print();

    LinkedList& operator=(const LinkedList& listOne);
    LinkedList& operator+=(const LinkedList& listOne);
    friend LinkedList operator+(const LinkedList& listOne , const LinkedList& listTwo);

    friend std::ostream& operator<<(std::ostream& os, const LinkedList& objPrink);

  protected:
    Node* head;
    Node* tail;
    
  private:
    void swap(LinkedList& otherList);   
};

#endif
