#include "singleLinkedList.hh"

LinkedList::LinkedList() : head(nullptr),tail(nullptr)
{ }

LinkedList::LinkedList(const LinkedList& obj) 
: LinkedList()
{
  Node* current = obj.head;

  while(current != nullptr) {
    append(current->data); 
    current = current->next;
  }
}

LinkedList::~LinkedList() 
{
   Node* curr = head;

   while(curr != nullptr) {
      Node* next = curr->next;
      delete curr;
      curr = next;
   }
   head = tail = nullptr;
}

void LinkedList::insert(int data)
{
 Node* node = new Node;
 node->data = data;
 node->next = head;
 head = node;

 if(tail == nullptr) {
    tail = head;
 }
}

void LinkedList::append(int data) 
{
  Node* newNode = new Node;
  newNode->data = data;
  
  if(isEmpty()) {

     head = tail = newNode;
     return;
  }

  tail->next = newNode;
  tail = newNode;
}

bool LinkedList::isEmpty() const { return head == nullptr; }

void LinkedList::print() 
{

   Node *curr = head;
   while(curr != nullptr)
   {
      std::cout << curr->data << "-->";
      curr = curr->next;
   }
   std::cout << "nullptr";
   std::cout << " [head = " << ((head == nullptr) ? (-1) : (head->data)) << "], [tail = " <<
      ((tail == nullptr) ? (-1) : (tail->data)) << "]" << std::endl;
}

void LinkedList::swap(LinkedList &other) 
{
 using std::swap;
 
  swap(head , other.head);
  swap(tail , other.tail); 
}

LinkedList& LinkedList::operator=(const LinkedList& listTwo) 
{
  LinkedList tempNode(listTwo);
  swap(tempNode);

  return *this;
}

LinkedList& LinkedList::operator+=(const LinkedList& rhs) 
{
  LinkedList* newNode = new LinkedList(rhs);
  
  if(isEmpty())
    head = newNode->head;
  else
    tail->next = newNode->head;
  
  tail = newNode->tail;

  newNode->head = newNode->tail = nullptr;

  delete newNode;
  
  return *this;
}

LinkedList operator+(const LinkedList& listOne , const LinkedList& listTwo)
{
  LinkedList list(listOne);
  
  list += listTwo;
     
  return list; 
}

std::ostream& operator<<(std::ostream& os, const LinkedList& objPrint) 
{
   Node *curr = objPrint.head;

   while(curr != nullptr)
   {
      os << curr->data << "-->";
      curr = curr->next;
   }
   os << "nullptr";
   os << " [head = " << ((objPrint.head == nullptr) ? (-1) : ((objPrint.head)->data)) << "], [tail = " <<
      ((objPrint.tail == nullptr) ? (-1) : ((objPrint.tail)->data)) << "]" << std::endl;

  return os;
}

int main()
{
  LinkedList list1;
  list1.insert(1);
  list1.append(2);
  list1.append(3);
  list1.append(4);
  list1.append(5);

  LinkedList list2;
  list2.insert(6);
  list2.append(7);
  list2.append(8);
  list2.append(9);
  list2.append(10);

  list1 = list1 + list2;

  std::cout << list1;
  std::cout << list2;

  return 0;
}

